<?php

$dbHost = 'localhost';
$dbUsername = 'hoot';
$dbPassword =  '';
$dbName = 'cadastro';

$conexao = new mysqli ($dbHost,$dbUsername,$dbPassword,$dbName);

?>
