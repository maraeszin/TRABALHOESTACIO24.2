<?php
if(isset($_POST['submit']))
{
    include_once('config.php');
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $result = mysqli_query(conexao, "INSERT INTO usuarios(nome,email,senha
    VALUES('&nome','&email','&senha')");
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="cadastro.css">
    <title>Cadastro</title>
    <style>
        .error {
            color: red;
        }
        /* Definindo uma fonte agradável */
body {
    font-family: 'Arial', sans-serif;
    background-color: #2e2e2e; /* Preto */
    color: #fff;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* Container do formulário */
form {
    background: rgba(255, 255, 255, 0.1);
    padding: 40px;
    border-radius: 10px;
    width: 400px;
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
    text-align: center;
}

/* Título do formulário */
h2 {
    color: #ff3366; /* Rosa */
    margin-bottom: 25px;
    font-size: 28px;
    font-weight: bold;
}

/* Estilo dos rótulos */
label {
    display: block;
    margin-bottom: 8px;
    font-size: 14px;
    color: #fff;
    text-align: left;
}

/* Estilo dos campos de entrada */
input[type="text"],
input[type="email"],
input[type="password"],
input[type="number"],
select {
    width: 100%;
    padding: 12px;
    margin: 10px 0 20px;
    border: 2px solid #ff3366; /* Rosa */
    border-radius: 6px;
    background-color: #333; /* Escuro */
    color: #fff;
    font-size: 16px;
    transition: border 0.3s ease-in-out;
}

/* Efeito de foco nos campos */
input[type="text"]:focus,
input[type="email"]:focus,
input[type="password"]:focus,
input[type="number"]:focus,
select:focus {
    border-color: #ff6699; /* Rosa mais claro */
    outline: none;
}

/* Mensagens de erro */
.error {
    color: #ff4d4d; /* Vermelho */
    font-size: 12px;
    margin-bottom: 10px;
}

/* Estilo do botão de envio */
input[type="submit"] {
    background: #ff3366; /* Rosa */
    color: #fff;
    border: none;
    padding: 12px 25px;
    font-size: 16px;
    cursor: pointer;
    border-radius: 6px;
    width: 100%;
    transition: background 0.3s ease-in-out;
}

/* Efeito no botão */
input[type="submit"]:hover {
    background: #ff6699; /* Rosa mais claro */
}

/* Link para login */
a {
    color: #ff3366; /* Rosa */
    text-decoration: none;
    margin-top: 20px;
    font-size: 14px;
    display: inline-block;
}

a:hover {
    text-decoration: underline;
}

    </style>
</head>
<body>
    <h2>Formulário de Cadastro</h2>
    
    <form id="meuFormulario" onsubmit="return validarFormulario()">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome">
        <span id="erroNome" class="error"></span><br><br>

        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email">
        <span id="erroEmail" class="error"></span><br><br>

        <label for="senha">Senha:</label>
        <input type="password" id="senha" name="senha">
        <span id="erroSenha" class="error"></span><br><br>

        <label for="confirmarSenha">Confirmar Senha:</label>
        <input type="password" id="confirmarSenha" name="confirmarSenha">
        <span id="erroConfirmarSenha" class="error"></span><br><br>

        <input type="submit" value="Cadastrar">
    </form>

    <script>
        function validarFormulario() {
            let valido = true;

            // Limpar mensagens de erro anteriores
            document.getElementById("erroNome").textContent = "";
            document.getElementById("erroEmail").textContent = "";
            document.getElementById("erroSenha").textContent = "";
            document.getElementById("erroConfirmarSenha").textContent = "";

            // Validação do campo Nome
            const nome = document.getElementById("nome").value;
            if (nome.trim() === "") {
                document.getElementById("erroNome").textContent = "O nome é obrigatório.";
                valido = false;
            }

            // Validação do campo E-mail
            const email = document.getElementById("email").value;
            if (email.trim() === "") {
                document.getElementById("erroEmail").textContent = "O e-mail é obrigatório.";
                valido = false;
            }

            // Validação do campo Senha
            const senha = document.getElementById("senha").value;
            if (senha.trim() === "") {
                document.getElementById("erroSenha").textContent = "A senha é obrigatória.";
                valido = false;
            }

            // Validação do campo Confirmar Senha
            const confirmarSenha = document.getElementById("confirmarSenha").value;
            if (confirmarSenha !== senha) {
                document.getElementById("erroConfirmarSenha").textContent = "As senhas não coincidem.";
                valido = false;
            }

            if (valido) {
                // Salvar dados no localStorage
                const usuario = {
                    nome: nome,
                    email: email,
                    senha: senha
                };
                localStorage.setItem("usuario", JSON.stringify(usuario));  // Salvar o usuário como JSON
                alert("Cadastro realizado com sucesso!");
                window.location.href = "trivlogin.html";  // Redireciona para a página de login
            }

            return false;  // Impede o envio do formulário padrão
        }
    </script>
</body>
</html>
